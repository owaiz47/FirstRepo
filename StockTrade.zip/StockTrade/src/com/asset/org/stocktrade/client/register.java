package com.asset.org.stocktrade.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.datepicker.client.DatePicker;

public class register {
	private TextBox userT;
	private PasswordTextBox passT;
	private PasswordTextBox passT2;
	private DatePicker advancedDatePicker;
	private TextBox eT;
	private TextBox mT; 
	ListBox lb;
	
	
	
	private VerticalPanel vPanel;
	DialogBox d;
	
	
	public VerticalPanel ui()
	{
		vPanel = new VerticalPanel();
		vPanel.setSpacing(20);
		//vPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER );
		vPanel.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
		
		Label logi = new Label("Register Here");
		logi.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		vPanel.add(logi);
		
		HorizontalPanel hpan = new HorizontalPanel();
		
		Image uimg = new Image("/images/user.png");
		uimg.setPixelSize(30, 30);
		
		this.userT = new TextBox();
		
		hpan.add(uimg);
		userT.setText("Name");
		lb = new ListBox();
		lb.addItem("Mr.");
	    lb.addItem("Mrs.");
	    lb.addItem("Other");
	    lb.setHeight("26px");
	    hpan.add(lb);
		hpan.add(this.userT);
		
		vPanel.add(hpan);
		
		HorizontalPanel passH = new HorizontalPanel();
		
		Image pimg = new Image("/images/pass.png");
		pimg.setPixelSize(30, 30);
		
		
		this.passT = new PasswordTextBox();
		passH.add(pimg);
		Label c = new Label("Password");
		passH.add(c);
		passH.add(this.passT);
		
		vPanel.add(passH);
		
		HorizontalPanel passH2 = new HorizontalPanel();
		this.passT2 = new PasswordTextBox();
		Image pimg2 = new Image("/images/pass.png");
		pimg2.setPixelSize(30, 30);
		passH2.add(pimg2);
		Label cp = new Label("Confirm Password");
		passH2.add(cp);
		passH2.add(this.passT2);
		
		vPanel.add(passH2);
		
		Label dob = new Label("Date Of Birth");
		vPanel.add(dob);
		
		
		advancedDatePicker = new DatePicker();
		advancedDatePicker.setYearArrowsVisible(true);
		advancedDatePicker.setYearAndMonthDropdownVisible(true); 
		vPanel.add(advancedDatePicker);
		
		
		Label email = new Label("Email");
		vPanel.add(email);
		
		eT = new TextBox();
		vPanel.add(eT);
		
		Label mobile = new Label("Mobile");
		vPanel.add(mobile);
		
		mT = new TextBox();
		vPanel.add(mT);

		
		Button bt1 = new Button("Register");
		vPanel.add(bt1);
		
		bt1.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(ClickEvent event) {
				
				Customer customer = new Customer();
				
				customer.setName(userT.getText().toString());
				customer.setPassword(passT.getText().toString());
				customer.setcPassword(passT2.getText().toString());
				customer.setDob(advancedDatePicker.getValue().toString());
				customer.setEmail(eT.getText().toString());
				customer.setPhone(Long.parseLong(mT.getText()));
				if(lb.getSelectedIndex()==0)
				{
					customer.setGender("Male");
				}
				else if(lb.getSelectedIndex()==1)
				{
					customer.setGender("Female");
				}
				else
				{
					customer.setGender("Other");
				}
				
				
				StockServiceAsync stockAsync = GWT.create(StockService.class);
				stockAsync.createCustomer(customer,
						new AsyncCallback<Void>() {
							
							public void onFailure(Throwable caught) {
								//Window.alert("RPC failed");
							}

							@Override
							public void onSuccess(Void result) {
								// TODO Auto-generated method stub
								
							}
						});
				
				
				d = new DialogBox();
				String u = userT.getText().toString();
	    		d.setText("Successfully Registered as "+u);
	    		d.setAnimationEnabled(true);
	    		d.center();
	    		Button exit = new Button("Close");
	    		exit.setPixelSize(300, 23);
	    		d.setWidget(exit);
	    		exit.addClickHandler(new ClickHandler() {
				    @Override
					public void  onClick(ClickEvent event) {
				    	d.hide();
				    }
				  });
	    		
	    		d.show();
				
			}
			
		});
		
		
		
		
		
		HorizontalPanel notM = new HorizontalPanel();
		Button bt2 = new Button("Home");
		bt2.setWidth("450px");
		
		notM.add(bt2);
		
		vPanel.add(notM);
		
		 bt1.addClickHandler(new ClickHandler() {
			    @Override
				public void  onClick(ClickEvent event) {
			    	
			    	
			      
			      
			    }
			  });
		 
		 bt2.addClickHandler(new ClickHandler() {
			    @Override
				public void  onClick(ClickEvent event) {
			    	RootPanel.get("container").clear();
			    	main lo = new main();
					vPanel = lo.ui();
					RootPanel.get("container").add(vPanel);
					
			    }
			  });
		 
		 
		 
		 
		    logi.addStyleName("login");
			hpan.addStyleName("horizontal");
			uimg.addStyleName("uimg");
			pimg.addStyleName("pimg");
			this.userT.addStyleName("userT");
			passH.addStyleName("passH");
			this.passT.addStyleName("passT");
			bt1.addStyleName("bt1");
			bt2.addStyleName("bt2");
		 

		
		
		return vPanel;
		
	}
		


}
