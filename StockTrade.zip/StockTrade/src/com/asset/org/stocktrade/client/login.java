package com.asset.org.stocktrade.client;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Hyperlink;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class login {
	private TextBox userT;
	private TextBox passT;
	
	public String ut = "owaiz";
	public String pt = "owaiz";
	DialogBox d;
	
	public VerticalPanel ui()
	{
		VerticalPanel vPanel = new VerticalPanel();
		vPanel.setSpacing(40);
		vPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER );
		vPanel.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
		
		Label logi = new Label("Login");
		vPanel.add(logi);
		Image logo1 = new Image("/images/back1.gif");
		//logo1.setHeight(100);
		//logo1.setWidth(100);
		logo1.setPixelSize(100, 100);
		vPanel.add(logo1);
		
		HorizontalPanel hpan = new HorizontalPanel();
		
		Image uimg = new Image("/images/user.png");
		uimg.setPixelSize(30, 30);
		
		this.userT = new TextBox();
		
		hpan.add(uimg);
		hpan.add(this.userT);
		
		vPanel.add(hpan);
		
		HorizontalPanel passH = new HorizontalPanel();
		
		Image pimg = new Image("/images/pass.png");
		pimg.setPixelSize(30, 30);
		
		
		this.passT = new TextBox();
		passH.add(pimg);
		passH.add(this.passT);
		
		vPanel.add(passH);
		
		Button bt1 = new Button("Login");
		vPanel.add(bt1);
		
		bt1.addClickHandler(new ClickHandler() {
		    @Override
			public void  onClick(ClickEvent event) {
		    	
		    	String u = userT.getText().toString();
		    	String p = passT.getText().toString();
		    	
		    	if(u==ut && p==pt)
		    	{
		    		d = new DialogBox();
		    		d.setText("Successfully LoggedIn as "+u);
		    		d.setAnimationEnabled(true);
		    		d.center();
		    		Button exit = new Button("Close");
		    		exit.setPixelSize(300, 23);
		    		d.setWidget(exit);
		    		exit.addClickHandler(new ClickHandler() {
					    @Override
						public void  onClick(ClickEvent event) {
					    	d.hide();
					    }
					  });
		    		
		    		d.show();
		    	}
		    	
		    	else
		    	{
		    		d = new DialogBox();
		    		d.setText("Not an authorized ENTRY!!!!");
		    		d.setAnimationEnabled(true);
		    		d.center();
		    		Label le = new Label("You are not an authorized User"+"Please check the credentials entered once");
		    		d.setWidget(le);
		    		d.show();
		    		Button exit = new Button("Close");
		    		exit.setPixelSize(300, 23);
		    		d.setWidget(exit);
		    		exit.addClickHandler(new ClickHandler() {
					    @Override
						public void  onClick(ClickEvent event) {
					    	d.hide();
					    }
					  });
		    		
		    	}
		    	
		    }
		  });
		
		Hyperlink fp = new Hyperlink("Forgot Password?","");
		vPanel.add(fp);
		
		HorizontalPanel notM = new HorizontalPanel();
		Label nm = new Label("Not A Member?");
		Button bt2 = new Button("SignUp");
		
		notM.add(nm);
		notM.add(bt2);
		
		vPanel.add(notM);
		
		 bt2.addClickHandler(new ClickHandler() {
			    @Override
				public void  onClick(ClickEvent event) {
			    	
			    	RootPanel.get("container").clear();
			    	VerticalPanel vPanel = new VerticalPanel();
			    	RootPanel.get("container").clear();
			    	register lo = new register();
			    	vPanel = lo.ui();
			    	RootPanel.get("container").add(vPanel);

			    }
			  });
		 
		    logi.addStyleName("login");
			logo1.addStyleName("logoimg");
			hpan.addStyleName("horizontal");
			uimg.addStyleName("uimg");
			pimg.addStyleName("pimg");
			this.userT.addStyleName("userT");
			passH.addStyleName("passH");
			this.passT.addStyleName("passT");
			bt1.addStyleName("bt1");
			bt2.addStyleName("bt2");
			nm.addStyleName("notMem");
		 

		
		
		return vPanel;
		
	}

}
