package com.asset.org.stocktrade.client;

import java.io.Serializable;

public class Customer implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int id;
	private String Name;
	private String userName;
	private  long phone;
	private String Email;
	private String Gender;
	private String Password;
	private String cPassword;
	private String dob;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	
	
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
	
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	
	
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
	
	public String getcPassword() {
		return cPassword;
	}
	
	public void setcPassword(String cPassword) {
		this.cPassword = cPassword;
	}
	
	
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	
	
	public Customer(int id, String name, String userName, long phone, String email, String gender, String password,
			String cPassword, String dob) {
		super();
		this.id = id;
		Name = name;
		this.userName = userName;
		this.phone = phone;
		Email = email;
		Gender = gender;
		Password = password;
		this.cPassword = cPassword;
		this.dob = dob;
	}
	public Customer() {
		super();
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", Name=" + Name + ", userName=" + userName + ", phone=" + phone + ", Email="
				+ Email + ", Gender=" + Gender + ", Password=" + Password + ", cPassword=" + cPassword + ", dob=" + dob
				+ "]";
	}
	
	

	
	
	
}
