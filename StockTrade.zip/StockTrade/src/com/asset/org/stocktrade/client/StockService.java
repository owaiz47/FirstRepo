package com.asset.org.stocktrade.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;


@RemoteServiceRelativePath("greet")
public interface StockService extends RemoteService{
	
	public void createCustomer(Customer customer);
	/*public boolean isValidLogin(Customer customer);
	public String findByUsername(Customer userName);
	public int findById(Customer id);*/

}
