package com.asset.org.stocktrade.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface StockServiceAsync {

	void createCustomer(Customer customer , AsyncCallback<Void> callback);

	/*void isValidLogin(Customer customer, AsyncCallback<Boolean> callback);

	void findByUsername(Customer userName, AsyncCallback<String> callback);

	void findById(Customer id, AsyncCallback<Integer> callback);
*/
	

}
