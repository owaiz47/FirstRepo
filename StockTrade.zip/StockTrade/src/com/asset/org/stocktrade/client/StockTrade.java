package com.asset.org.stocktrade.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;



/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class StockTrade implements EntryPoint {
	

	private VerticalPanel vPanel;

	@Override
	public void onModuleLoad() {
		
		
		Label logoName = new Label("Stock Trading");
		logoName.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		logoName.addStyleName("logo_name");
		Image logoimg = new Image("/images/logo.gif");
		logoimg.addStyleName("logo_img");
		logoimg.setPixelSize(100, 100);
		
		HorizontalPanel logoPanel = new HorizontalPanel();
		
		logoPanel.add(logoimg);
		logoPanel.add(logoName);
		
		logoPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		
		RootPanel.get("nav").add(logoPanel);
		
		
		
		VerticalPanel vp = new VerticalPanel();
		
		HorizontalPanel hp = new HorizontalPanel();
		
		Button home = new Button("Home");
		Button login = new Button("Login");
		Button reg = new Button("Register");
		
		home.setPixelSize(70, 30);
		login.setPixelSize(70, 30);
		reg.setPixelSize(70, 30);
		
		hp.add(home);
		hp.add(login);
		hp.add(reg);
		RootPanel.get("nav").add(hp);
		
		RootPanel.get("container").clear();
    	main lo = new main();
		vPanel = lo.ui();
		RootPanel.get("container").add(vPanel);
		
		
		home.addClickHandler(new ClickHandler() {
		    @Override
			public void  onClick(ClickEvent event) {
		    	RootPanel.get("container").clear();
		    	main lo = new main();
				vPanel = lo.ui();
				RootPanel.get("container").add(vPanel);
				
		    }
		  });
		
		
		
		reg.addClickHandler(new ClickHandler() {
		    @Override
			public void  onClick(ClickEvent event) {
		    	RootPanel.get("container").clear();
		    	register lo = new register();
				vPanel = lo.ui();
				RootPanel.get("container").add(vPanel);
				
		    }
		  });
		
		
		
		login.addClickHandler(new ClickHandler() {
		    @Override
			public void  onClick(ClickEvent event) {
		    	RootPanel.get("container").clear();
				login lo = new login();
				vPanel = lo.ui();
				RootPanel.get("container").add(vPanel);
		    }
		  });
		
		home.addStyleName("bt1");
		login.addStyleName("bt1");
		reg.addStyleName("bt1");
		
		
		RootPanel.get("container").add(vp);
		

			}
}

