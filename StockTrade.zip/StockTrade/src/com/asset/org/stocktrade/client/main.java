package com.asset.org.stocktrade.client;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class main {
	private TextBox t;
	private FlexTable stockTable;
	
	public VerticalPanel  ui()
	{
		VerticalPanel vPanel = new VerticalPanel();
		HorizontalPanel addPanel = new HorizontalPanel();
		
		
		vPanel.setSpacing(40);
		vPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER );
		vPanel.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
		Label home = new Label("HOME PAGE");
		home.addStyleName("home_name");
		home.setSize("100px", "100px");
		home.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		vPanel.add(home);
		
		home.addStyleName("home");
		
		stockTable = new FlexTable();
		stockTable.setBorderWidth(1);
		stockTable.setCellSpacing(5);
	    stockTable.setCellPadding(3);
		
		 stockTable.setText(0, 0, "Company");  
		 stockTable.setText(0, 1, "Price");
		 stockTable.setText(0, 2, "Change");
		 stockTable.setText(0, 3, "Remove");
		 
		 Button remove = new Button("Remove");
		 remove.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				stockTable.setText(1,0, "");
				
			}
		});
		 
		 stockTable.setWidget(1, 3, remove);
		 
		 
		vPanel.add(stockTable);  
		
		
		t = new TextBox();
		addPanel.add(t);
		Button add = new Button("Add New");
		
		add.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				String upload = t.getText();
				stockTable.setText(1,0,upload);
				
				
				
			}
		});
		
		
		
		addPanel.add(add);

		vPanel.add(addPanel);
		return vPanel;
	}
}
