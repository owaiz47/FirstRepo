package com.asset.org.stocktrade.server;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.asset.org.stocktrade.client.Customer;

public class StockDAOImpl implements StockDAO {
	
	private SessionFactory factory;

	@Override
	public void createCustomer(Customer customer) {  
		
		customer.setEmail("hellowoelrdjkl");
		try {
	         factory = new Configuration().configure().buildSessionFactory();
	      } catch (Throwable ex) { 
	         System.err.println("Failed to create sessionFactory object." + ex);
	         throw new ExceptionInInitializerError(ex); 
	      }
		
		Session session = factory.openSession();
	      Transaction tx = null;    
	      
	      try {
	         tx = session.beginTransaction();
	         session.save(customer);
	         tx.commit();
	      } catch (Exception e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		
		
		
		
	}


	/*@Override
	public boolean isValidLogin(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String findByUsername(Customer userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int findById(Customer id) {
		// TODO Auto-generated method stub
		return 0;
	}*/

}
