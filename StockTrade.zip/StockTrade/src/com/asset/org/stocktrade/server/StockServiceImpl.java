package com.asset.org.stocktrade.server;

import com.asset.org.stocktrade.client.Customer;
import com.asset.org.stocktrade.client.StockService;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class StockServiceImpl extends RemoteServiceServlet implements StockService {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private StockDAO stockdao;
	
	

	@Override
	public void createCustomer(Customer customer) {
		stockdao = new StockDAOImpl();
		stockdao.createCustomer(customer);
		// TODO Auto-generated method stub
	}

	/*@Override
	public boolean isValidLogin(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String findByUsername(Customer userName) {
		// TODO Auto-generated method stub
		return stockdao.findByUsername(userName);
	}

	@Override
	public int findById(Customer id) {
		// TODO Auto-generated method stub
		return stockdao.findById(id);
	}*/

}
