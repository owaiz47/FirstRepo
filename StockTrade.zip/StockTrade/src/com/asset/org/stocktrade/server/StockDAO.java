package com.asset.org.stocktrade.server;

import com.asset.org.stocktrade.client.Customer;

public interface StockDAO {
	
		
		public void createCustomer(Customer customer);
		/*public boolean isValidLogin(Customer customer);
		public String findByUsername(Customer userName);
		public int findById(Customer id);
*/
	}


